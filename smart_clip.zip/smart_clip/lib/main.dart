import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:android_intent_plus/android_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const SmartClipApp());

// ---------- الموديل ----------
class Clip {
  String text, type;
  DateTime time;
  bool pinned;
  String? summary;
  Clip(this.text, this.type, this.time, {this.pinned = false, this.summary});
  Map<String, dynamic> toJson() => {'t': text, 'y': type, 'd': time.toIso8601String(), 'p': pinned, 's': summary};
  factory Clip.fromJson(Map<String, dynamic> j) =>
      Clip(j['t'], j['y'], DateTime.parse(j['d']), pinned: j['p'] ?? false, summary: j['s']);
}

// تصنيف ذكي تلقائي (يعمل بدون إنترنت)
String classify(String s) {
  final t = s.trim();
  if (RegExp(r'^(https?://|www\.)\S+$').hasMatch(t)) return 'رابط';
  if (RegExp(r'^[\w.+-]+@[\w-]+\.[\w.]+$').hasMatch(t)) return 'إيميل';
  if (RegExp(r'^\+?[\d\s\-()]{7,16}$').hasMatch(t)) return 'هاتف';
  if (RegExp(r'^[\d.,]+$').hasMatch(t)) return 'رقم';
  if (t.contains('\n') && RegExp(r'[{};]|=>|\bfunction\b|\bdef\b|\bclass\b|</\w+>').hasMatch(t)) return 'كود';
  return 'نص';
}

const typeIcons = {
  'رابط': Icons.link,
  'إيميل': Icons.email_outlined,
  'هاتف': Icons.phone_outlined,
  'رقم': Icons.numbers,
  'كود': Icons.code,
  'نص': Icons.notes,
};

// ---------- التطبيق ----------
class SmartClipApp extends StatefulWidget {
  const SmartClipApp({super.key});
  @override
  State<SmartClipApp> createState() => _AppState();
}

class _AppState extends State<SmartClipApp> {
  ThemeMode mode = ThemeMode.system;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => setState(() => mode = ThemeMode.values[p.getInt('theme') ?? 0]));
  }

  void setMode(ThemeMode m) async {
    setState(() => mode = m);
    (await SharedPreferences.getInstance()).setInt('theme', m.index);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Smart Clip',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        darkTheme: ThemeData(colorSchemeSeed: Colors.indigo, brightness: Brightness.dark, useMaterial3: true),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: Home(mode: mode, onMode: setMode),
      );
}

class Home extends StatefulWidget {
  final ThemeMode mode;
  final void Function(ThemeMode) onMode;
  const Home({super.key, required this.mode, required this.onMode});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  List<Clip> items = [];
  String q = '', filter = 'الكل', apiKey = '', last = '';
  bool busy = false, svcOn = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load().then((_) => check());
    timer = Timer.periodic(const Duration(milliseconds: 1500), (_) => check());
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) check();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('clips');
    if (raw != null) items = (jsonDecode(raw) as List).map((e) => Clip.fromJson(e)).toList();
    apiKey = p.getString('key') ?? '';
    setState(() {});
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('clips', jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  void addClip(String t, DateTime time) {
    final i = items.indexWhere((c) => c.text == t);
    if (i >= 0) {
      final c = items.removeAt(i)..time = time;
      items.insert(0, c);
    } else {
      items.insert(0, Clip(t, classify(t), time));
      if (items.length > 1000) items.removeLast();
    }
  }

  Future<void> check() async {
    var changed = false;
    // 1) ما التقطته خدمة إمكانية الوصول في الخلفية
    final p = await SharedPreferences.getInstance();
    await p.reload();
    final on = p.getBool('svc_on') ?? false;
    final raw = p.getString('pending');
    if (raw != null && raw != '[]') {
      await p.remove('pending');
      try {
        for (final e in jsonDecode(raw) as List) {
          final t = (e['t'] as String).trim();
          if (t.isEmpty) continue;
          addClip(t, DateTime.fromMillisecondsSinceEpoch(e['d'] as int));
          changed = true;
        }
      } catch (_) {}
    }
    // 2) الحافظة الحالية (والتطبيق مفتوح)
    final d = await Clipboard.getData('text/plain');
    final t = d?.text?.trim();
    if (t != null && t.isNotEmpty && t != last) {
      last = t;
      addClip(t, DateTime.now());
      changed = true;
    }
    if (changed || on != svcOn) {
      setState(() => svcOn = on);
    }
    if (changed) save();
  }

  void accessHelp() {
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تفعيل الحفظ في الخلفية'),
          content: const Text(
              '1) اضغط "إعدادات التطبيق" ثم ⋮ في الأعلى ثم "السماح بالإعدادات المقيّدة" (أندرويد 13 وما بعده فقط).\n\n'
              '2) اضغط "إمكانية الوصول" وافتح Smart Clip ثم فعّله.\n\n'
              'الخدمة لا تقرأ شاشتك، تُستخدم فقط لمراقبة الحافظة.'),
          actions: [
            TextButton(
              onPressed: () => AndroidIntent(
                action: 'android.settings.APPLICATION_DETAILS_SETTINGS',
                data: 'package:com.smartclip.smart_clip',
              ).launch(),
              child: const Text('إعدادات التطبيق'),
            ),
            TextButton(
              onPressed: () => AndroidIntent(action: 'android.settings.ACCESSIBILITY_SETTINGS').launch(),
              child: const Text('إمكانية الوصول'),
            ),
          ],
        ),
      ),
    );
  }

  void snack(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));

  Future<void> summarize(Clip c) async {
    if (apiKey.isEmpty) return snack('أضف مفتاح API من الإعدادات أولاً');
    setState(() => busy = true);
    try {
      final r = await http.post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json'},
        body: jsonEncode({
          'model': 'claude-haiku-5-5',
          'max_tokens': 200,
          'messages': [
            {'role': 'user', 'content': 'لخّص النص التالي في سطر واحد بالعربية بدون مقدمات:\n${c.text}'}
          ]
        }),
      );
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (r.statusCode != 200) throw j['error']?['message'] ?? 'خطأ ${r.statusCode}';
      c.summary = j['content'][0]['text'];
      await save();
    } catch (e) {
      snack('فشل التلخيص: $e');
    }
    setState(() => busy = false);
  }

  String fmt(DateTime d) {
    String z(int n) => n.toString().padLeft(2, '0');
    return '${d.year}/${z(d.month)}/${z(d.day)}  ${z(d.hour)}:${z(d.minute)}';
  }

  void settings() {
    final ctrl = TextEditingController(text: apiKey);
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('الإعدادات'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('مفتاح Anthropic API (اختياري، لتفعيل التلخيص الذكي)', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            TextField(controller: ctrl, obscureText: true, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'sk-ant-...')),
            const SizedBox(height: 16),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('تلقائي')),
                ButtonSegment(value: ThemeMode.light, label: Text('نهاري')),
                ButtonSegment(value: ThemeMode.dark, label: Text('ليلي')),
              ],
              selected: {widget.mode},
              onSelectionChanged: (s) {
                widget.onMode(s.first);
                Navigator.pop(context);
              },
            ),
          ]),
          actions: [
            TextButton(
                onPressed: () async {
                  apiKey = ctrl.text.trim();
                  (await SharedPreferences.getInstance()).setString('key', apiKey);
                  if (mounted) Navigator.pop(context);
                },
                child: const Text('حفظ')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final types = ['الكل', 'المثبّت', ...typeIcons.keys];
    var vis = items.where((c) {
      if (filter == 'المثبّت' && !c.pinned) return false;
      if (filter != 'الكل' && filter != 'المثبّت' && c.type != filter) return false;
      final s = q.toLowerCase();
      return s.isEmpty || c.text.toLowerCase().contains(s) || (c.summary ?? '').toLowerCase().contains(s);
    }).toList();
    vis.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));

    return Scaffold(
      appBar: AppBar(title: const Text('Smart Clip'), actions: [
        IconButton(icon: const Icon(Icons.settings_outlined), onPressed: settings),
      ]),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'ابحث في المنسوخات...',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
              isDense: true,
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            children: [
              for (final t in types)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                  child: ChoiceChip(label: Text(t), selected: filter == t, onSelected: (_) => setState(() => filter = t)),
                ),
            ],
          ),
        ),
        if (busy) const LinearProgressIndicator(),
        if (!svcOn)
          Card(
            margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
            color: Theme.of(context).colorScheme.secondaryContainer,
            child: ListTile(
              leading: const Icon(Icons.bolt),
              title: const Text('فعّل الحفظ التلقائي في الخلفية'),
              subtitle: const Text('اضغط لمعرفة الخطوات'),
              onTap: accessHelp,
            ),
          ),
        Expanded(
          child: vis.isEmpty
              ? const Center(child: Text('انسخ أي نص وسيظهر هنا تلقائياً'))
              : ListView.builder(
                  itemCount: vis.length,
                  itemBuilder: (_, i) {
                    final c = vis[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      child: ListTile(
                        leading: Icon(typeIcons[c.type]),
                        title: Text(c.text, maxLines: 3, overflow: TextOverflow.ellipsis),
                        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          if (c.summary != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text('✨ ${c.summary}', style: TextStyle(color: Theme.of(context).colorScheme.primary)),
                            ),
                          Text('${c.type} • ${fmt(c.time)}', style: const TextStyle(fontSize: 11)),
                        ]),
                        onTap: () {
                          last = c.text;
                          Clipboard.setData(ClipboardData(text: c.text));
                          snack('تم النسخ');
                        },
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'pin') setState(() => c.pinned = !c.pinned);
                            if (v == 'ai') await summarize(c);
                            if (v == 'del') setState(() => items.remove(c));
                            save();
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'pin', child: Text(c.pinned ? 'إلغاء التثبيت' : 'تثبيت')),
                            const PopupMenuItem(value: 'ai', child: Text('تلخيص بالذكاء الاصطناعي')),
                            const PopupMenuItem(value: 'del', child: Text('حذف')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
