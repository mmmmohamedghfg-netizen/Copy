import re

p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
snippet = open('native/manifest_snippet.xml', encoding='utf-8').read()

s = re.sub(r'android:label="[^"]*"', 'android:label="Smart Clip"', s, count=1)
s = s.replace('</application>', snippet + '\n    </application>', 1)
s = s.replace('<application',
              '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
open(p, 'w', encoding='utf-8').write(s)
print(s)
