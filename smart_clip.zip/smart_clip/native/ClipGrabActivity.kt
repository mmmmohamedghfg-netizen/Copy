package com.smartclip.smart_clip

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context

/** نشاط شفاف يأخذ التركيز لحظياً ليقرأ الحافظة ثم يُغلق */
class ClipGrabActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            ClipStore.read(this, cm)?.let { ClipStore.add(this, it) }
            finish()
            overridePendingTransition(0, 0)
        }
    }
}
