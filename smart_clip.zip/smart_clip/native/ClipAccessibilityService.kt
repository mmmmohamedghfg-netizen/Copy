package com.smartclip.smart_clip

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray
import org.json.JSONObject

/** يخزّن المنسوخات في ملف مشترك مع Flutter (مفتاح pending) */
object ClipStore {
    private var last = ""

    fun read(ctx: Context, cm: ClipboardManager): String? {
        return try {
            val clip = cm.primaryClip
            if (clip == null || clip.itemCount == 0) {
                null
            } else {
                val extras = clip.description.extras
                // تجاهل ما تعلّمه تطبيقات كلمات المرور كمحتوى حساس
                if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) {
                    null
                } else {
                    clip.getItemAt(0).coerceToText(ctx)?.toString()
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    @Synchronized
    fun add(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty() || t == last) return
        last = t
        val p = ctx.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(p.getString("flutter.pending", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        arr.put(JSONObject().put("t", t).put("d", System.currentTimeMillis()))
        p.edit().putString("flutter.pending", arr.toString()).apply()
    }

    fun setServiceOn(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .edit().putBoolean("flutter.svc_on", on).apply()
    }
}

class ClipAccessibilityService : AccessibilityService() {
    private lateinit var cm: ClipboardManager
    private val handler = Handler(Looper.getMainLooper())
    private var lastGrab = 0L

    private val listener = ClipboardManager.OnPrimaryClipChangedListener { readClip(true) }
    private val poll = Runnable { readClip(false) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(listener)
        ClipStore.setServiceOn(this, true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // ضغطة/تحديد نص: غالباً المستخدم على وشك النسخ، نتحقق بعد لحظة
        handler.removeCallbacks(poll)
        handler.postDelayed(poll, 400)
    }

    override fun onInterrupt() {}

    private fun readClip(fromChange: Boolean) {
        val text = ClipStore.read(this, cm)
        if (text != null) {
            ClipStore.add(this, text)
        } else if (fromChange) {
            // أندرويد 10+ يمنع القراءة من الخلفية: نفتح نشاط شفاف لحظياً ليقرأ الحافظة
            val now = System.currentTimeMillis()
            if (now - lastGrab > 1000) {
                lastGrab = now
                try {
                    startActivity(
                        Intent(this, ClipGrabActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    )
                } catch (e: Throwable) {
                }
            }
        }
    }

    private fun stop() {
        handler.removeCallbacks(poll)
        if (::cm.isInitialized) {
            try {
                cm.removePrimaryClipChangedListener(listener)
            } catch (e: Throwable) {
            }
        }
        ClipStore.setServiceOn(this, false)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stop()
        super.onDestroy()
    }
}
